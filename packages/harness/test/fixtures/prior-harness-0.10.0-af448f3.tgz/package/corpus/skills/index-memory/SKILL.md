---
name: index-memory
user-invocable: false
description: Rebuild knowledge manifest via harness index. Use after /compound-learnings. Not for writing solutions.
argument-hint: "[optional — ignored; use harness index]"
---

# Index Memory (CLI-first)

Rebuild `knowledge/manifest.yaml` deterministically. Contract: [`harness-tool-contract.md`](../references/harness-tool-contract.md).

## Step

```bash
harness index --workspace . --json
```

Reports entry count and manifest path. Scans `<copilot-home>/knowledge/solutions/` (default `~/.copilot`; the home rule is in `knowledge-locations.md`) and repo `docs/solutions/` when present.

## When

- After `/compound-learnings` or `/auto-compound`
- Manifest empty or stale

## Guardrails

- Does not delete solution files — index only.
- Do not rebuild YAML by hand in chat.

## Trigger Examples

**Should trigger:**
- "Index the learning just published."
- "Rebuild the stale knowledge index."
- "Refresh lookup after an accepted solution."

**Should not trigger:**
- "Write a new learning."
- "Implement a product feature."
- "Choose which learning is relevant."
