#!/usr/bin/env node
/** Stop gate: require fresh passed evidence after every successful governed mutation. */
import { readPolicySource } from './lib/policy-snapshot.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { validateEvidenceBinding, callProofAuthority } from './lib/proof-authority.mjs';
import { writeHookEvent } from './lib/events.mjs';
import { stopBlockOutput } from './lib/hook-output.mjs';
import { loadHookPolicy } from './lib/policy.mjs';
import { writeSessionState } from './lib/session-state.mjs';
import { resolveHookWorkspace } from './lib/tool-payload.mjs';
import { authorityBin } from './lib/authority-bin.mjs';

const startedAt = Date.now();
// Leave five seconds for hook startup/output within the configured 90-second deadline.
const stopBudgetMs = 85000;
const proofCallBudgetMs = 10000;
const remainingBudget = () => Math.max(1, stopBudgetMs - (Date.now() - startedAt));
const proofTimeout = () => Math.min(proofCallBudgetMs, remainingBudget());

function readPayload() {
  try {
    return JSON.parse(fs.readFileSync(0, 'utf8') || '{}');
  } catch {
    return {};
  }
}

const input = readPayload();
const workspace = resolveHookWorkspace(input);
const policy = loadHookPolicy(workspace, { ttlKey: 'evidence_ttl_hours', ttlDefault: 24, rule: 'completion' });
const sessionPath = path.join(workspace, '.harness', 'session.json');
let session = null;

function output(value) {
  console.log(JSON.stringify(value));
}

function event(fields) {
  writeHookEvent(workspace, input, {
    type: 'session_end',
    mutation: Boolean(session?.lastEditAt),
    targets: session?.lastEditTargets || [],
    targetResolved: true,
    plan: session?.activePlan || null,
    gate: session?.gateStatus || null,
    durationMs: Date.now() - startedAt,
    ...fields,
  });
}

function deny(message) {
  const planFlag = session?.activePlan ? ` --plan ${session.activePlan}` : '';
  const recipe = `; next: run \`harness verify${planFlag} --workspace . --json\` after the edit is complete, record a publish or no-learning decision with \`harness compound${planFlag} --learning-decision <file>\`, and complete the plan with \`harness plan-update${planFlag} --file <complete-decision.json>\` before stopping`;
  const base = input.stop_hook_active
    ? `${message}; verification is still pending after the prior Stop block`
    : message;
  const reason = `${base}${recipe}`;
  console.error(`[harness hook] Completion blocked: ${reason}`);
  if (policy.enforcement !== 'enforce') {
    event({ decision: 'warn', result: 'warn', blockedReason: reason });
    output({ continue: true, systemMessage: `[harness hook] Completion evidence unavailable: ${reason}` });
    process.exit(0);
  }
  event({ decision: 'block', result: 'fail', blockedReason: reason });
  output(stopBlockOutput(reason));
  process.exit(0);
}

function allow(reason) {
  event({ decision: 'allow', result: 'pass' });
  output({ continue: true, systemMessage: reason });
  process.exit(0);
}

if (!fs.existsSync(sessionPath)) {
  output({ continue: true });
  process.exit(0);
}

try {
  session = JSON.parse(readPolicySource(sessionPath)?.toString('utf8') || 'null');
} catch {
  deny('session is unreadable');
}

function refreshVerification(current) {
  const bin = authorityBin();
  const command = bin ? process.execPath : 'harness';
  const args = [...(bin ? [bin] : []), 'verify', '--json', '--no-events', '--workspace', workspace];
  if (current?.activePlan) args.push('--plan', current.activePlan);
  const result = spawnSync(command, args, {
    cwd: workspace,
    encoding: 'utf8',
    // Reserve time for both authority reads after refreshing missing evidence.
    timeout: Math.max(1, remainingBudget() - 2 * proofCallBudgetMs),
    env: process.env,
  });
  if (result.error || result.status == null) return current;
  try {
    return JSON.parse(readPolicySource(sessionPath)?.toString('utf8') || 'null');
  } catch {
    return current;
  }
}

if (!session || typeof session !== 'object') deny('session is unreadable');
if (!session.lastEditAt) allow('No successful governed mutation requires verification.');
const lastEditAt = Date.parse(session.lastEditAt);
if (!Number.isFinite(lastEditAt)) deny('last edit timestamp is missing or invalid');
if (!session.lastEvidencePath || !session.lastVerifyAt) session = refreshVerification(session);
if (!session.lastEvidencePath || !session.lastVerifyAt) deny('harness verify has not run');
const evidencePath = path.resolve(workspace, session.lastEvidencePath);
if (!evidencePath.startsWith(path.join(workspace, '.harness', 'evidence') + path.sep) || !fs.existsSync(evidencePath)) {
  deny('verification evidence is missing');
}

let evidence;
try {
  evidence = JSON.parse(readPolicySource(evidencePath)?.toString('utf8') || 'null');
} catch {
  deny('verification evidence is unreadable');
}
if (!evidence || typeof evidence !== 'object') deny('verification evidence is unreadable');
if (evidence.outcome === 'repeated-mistake') deny('verification outcome is repeated-mistake; run harness correct');
if (evidence.outcome !== 'passed') deny(`verification outcome is ${evidence.outcome || 'unknown'}`);
const normalizedPlan = (value) => String(value || '').replace(/\\/g, '/');
if (session.activePlan && normalizedPlan(evidence.plan) !== normalizedPlan(session.activePlan)) {
  deny('verification evidence belongs to a different plan');
}
const bindingError = validateEvidenceBinding({
  workspace,
  planPath: evidence.plan,
  evidence,
  maxAgeHours: policy.ttl,
  timeout: proofTimeout(),
});
if (bindingError) deny(bindingError);
const lastVerifyAt = Date.parse(session.lastVerifyAt);
if (!Number.isFinite(lastVerifyAt)) deny('verification timestamp is missing or invalid');
const evidenceVerifiedAt = Date.parse(evidence.verifiedAt);
if (lastVerifyAt < lastEditAt || evidenceVerifiedAt < lastEditAt) {
  deny('files changed after the latest passed verification');
}
const completion = callProofAuthority(workspace, ['--validate-completion', '--plan', evidence.plan], { timeout: proofTimeout() });
if (!completion?.pass) deny(completion?.message || 'Current completion record cannot be validated; upgrade and retry completion');
session.lastCompletedEditAt = session.lastEditAt;
session.lastCompletionAt = new Date().toISOString();
try {
  writeSessionState(workspace, session);
} catch (error) {
  deny(`verification passed, but completion bookkeeping failed: ${error.message}`);
}
allow('Fresh passed Harness verification permits completion.');
